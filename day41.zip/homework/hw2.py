# 2. მოცემულია სია: fruits = ["apple", "banana", "cherry", "mango"]. 
# გამოიყენე for ციკლი, რათა დაბეჭდო ყველა ხილის სახელი დიდ ასოებით.

fruits = ["apple", "banana", "cherry", "mango"]

for i in range(0, len(fruits)):
    print(fruits[i].upper())