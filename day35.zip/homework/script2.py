"""3. დაწერეთ ამ ლოგიკით კოდი Python-ში:"""

age = int(input("Enter your age"))
if age > 18:
    print("You are adult 👨‍🦰")
else:
    print("You are not adult 👶")