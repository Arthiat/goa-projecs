"""1. "გადათარგმნეთ" ფსევდო კოდი Python-ზე."""

"""start
repeat until authorised = true
INPUT log_in
access_granted = true"""

name = input("Enter ur name :")
lastname = input("Enter a lastname")
age = int(input("Enter your age"))
print(name)
print(lastname)
print(age)
print("Registration is succesfull 🙌")